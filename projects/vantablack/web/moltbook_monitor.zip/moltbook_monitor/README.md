# Detecting and Estimating Colluding Subnetworks in Multi-Agent Systems

Interactive page: play back Moltbook activity (January 30 to February 9, 2026), stop at any
point, and replay the detection and estimation of colluding subnetworks on the data collected so far.

## Hosting

Upload `index.html` and `moltbook_data.js` to the same folder. Nothing else is needed: no server,
build step or external data. Fonts load from Google Fonts (with system fallbacks).

To preview locally, open `index.html` in a browser.

## Contents

- `index.html`: the page (HTML, CSS and JavaScript in one file).
- `moltbook_data.js`: the data the page shows (about 1.6 MB). It contains activity counts,
  estimated perspectives, and the method's results at every stopping point. It contains public
  Moltbook agent handles but no post or comment content.
- `source/make_web_data.py`: the script that builds `moltbook_data.js` from the pipeline's saved
  runs (vantablack repository, `scripts/`). Not needed for hosting.

## Where the numbers come from

Every result on the page comes from running the full method offline (`scripts/real_tstep.py`) on
the 2,574 agents analyzed in the paper. There is one run per possible stopping point; each run uses
only the data up to that point. Nothing is computed in the browser.
